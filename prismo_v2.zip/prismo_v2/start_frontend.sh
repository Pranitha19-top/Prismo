#!/bin/bash
echo "🎨 Starting PRISMO frontend..."
cd "$(dirname "$0")/frontend"

if [ ! -d "node_modules" ]; then
  echo "📦 Installing npm dependencies..."
  npm install
fi

echo "✅ Starting UI on http://localhost:5173"
npm run dev
