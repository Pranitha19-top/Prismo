"""
Auth utilities — JWT + bcrypt-compatible hashing.
Uses passlib if available, otherwise falls back to a simple hash for demo.
"""
import os
import hashlib
import hmac
import time
import json
import base64

SECRET_KEY = os.getenv("JWT_SECRET", "prismo-demo-secret-key-2024")
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = 24

# ── Password hashing ──────────────────────────────────────────────────────────

def _sha256_hash(password: str) -> str:
    """Deterministic demo hash. Replace with bcrypt in production."""
    salt = "prismo_salt_v1"
    return hashlib.sha256(f"{salt}{password}".encode()).hexdigest()

try:
    from passlib.context import CryptContext
    _ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
    def hash_password(password: str) -> str:
        return _ctx.hash(password)
    def verify_password(plain: str, hashed: str) -> bool:
        # Support both bcrypt and demo sha256
        if hashed.startswith("$2"):
            return _ctx.verify(plain, hashed)
        return hmac.compare_digest(_sha256_hash(plain), hashed)
except ImportError:
    def hash_password(password: str) -> str:
        return _sha256_hash(password)
    def verify_password(plain: str, hashed: str) -> bool:
        return hmac.compare_digest(_sha256_hash(plain), hashed)

# ── JWT ───────────────────────────────────────────────────────────────────────

def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64url_decode(s: str) -> bytes:
    pad = 4 - len(s) % 4
    return base64.urlsafe_b64decode(s + "=" * pad)

def _sign(msg: str) -> str:
    key = SECRET_KEY.encode()
    sig = hmac.new(key, msg.encode(), hashlib.sha256).digest()
    return _b64url_encode(sig)

try:
    from jose import jwt as jose_jwt, JWTError

    def create_token(data: dict) -> str:
        payload = {**data, "exp": int(time.time()) + TOKEN_EXPIRE_HOURS * 3600}
        return jose_jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    def decode_token(token: str) -> dict:
        try:
            return jose_jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        except JWTError:
            return {}

except ImportError:
    # Minimal JWT-like implementation
    def create_token(data: dict) -> str:
        header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
        payload_data = {**data, "exp": int(time.time()) + TOKEN_EXPIRE_HOURS * 3600}
        payload = _b64url_encode(json.dumps(payload_data).encode())
        sig = _sign(f"{header}.{payload}")
        return f"{header}.{payload}.{sig}"

    def decode_token(token: str) -> dict:
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return {}
            header, payload, sig = parts
            expected = _sign(f"{header}.{payload}")
            if not hmac.compare_digest(expected, sig):
                return {}
            data = json.loads(_b64url_decode(payload))
            if data.get("exp", 0) < int(time.time()):
                return {}
            return data
        except Exception:
            return {}
