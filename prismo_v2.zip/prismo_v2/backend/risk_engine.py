from datetime import date, datetime, timedelta
from sqlalchemy.orm import Session
from models import ZoneRisk, Worker, DisruptionEvent

METRO_CITIES = {"Bengaluru", "Hyderabad", "Mumbai", "Delhi", "Chennai", "Kolkata", "Pune", "Bangalore"}

def compute_risk_score(rain, temperature, aqi, traffic_level, curfew_status) -> float:
    if curfew_status:
        return 100.0
    score = 0.0
    score += min(rain / 20.0, 1.0) * 30
    score += min(aqi / 300.0, 1.0) * 20
    temp_factor = max(0, (temperature - 35) / 10.0) + max(0, (15 - temperature) / 10.0)
    score += min(temp_factor, 1.0) * 10
    score += ((traffic_level - 1) / 4.0) * 25
    score += 15
    return round(min(score, 100.0), 2)

def risk_level(score: float) -> str:
    if score < 35:
        return "LOW"
    elif score < 65:
        return "MEDIUM"
    return "HIGH"

def get_zone_7day_avg(db: Session, zone: str) -> float:
    cutoff = date.today() - timedelta(days=7)
    records = db.query(ZoneRisk).filter(ZoneRisk.zone == zone, ZoneRisk.date >= cutoff).all()
    if not records:
        return 30.0
    return round(sum(r.risk_score for r in records) / len(records), 2)

def get_zone_21day_avg(db: Session, zone: str) -> float:
    cutoff = date.today() - timedelta(days=21)
    records = db.query(ZoneRisk).filter(ZoneRisk.zone == zone, ZoneRisk.date >= cutoff).all()
    if not records:
        return 30.0
    return round(sum(r.risk_score for r in records) / len(records), 2)

def is_night_shift(shift_start: str, shift_end: str) -> bool:
    """Return True if shift overlaps 10PM-6AM."""
    try:
        sh = int(shift_start.split(":")[0])
        eh = int(shift_end.split(":")[0])
        night_hours = set(range(22, 24)) | set(range(0, 6))
        if sh <= eh:
            shift_hours = set(range(sh, eh))
        else:
            shift_hours = set(range(sh, 24)) | set(range(0, eh))
        return bool(shift_hours & night_hours)
    except Exception:
        return False

def compute_weekly_premium(worker: Worker, db: Session) -> dict:
    """Dynamic weekly premium with full breakdown."""
    avg_risk_7d = get_zone_7day_avg(db, worker.zone)
    avg_risk_21d = get_zone_21day_avg(db, worker.zone)

    # Base premium by current risk level
    today_risk = avg_risk_7d
    if today_risk < 35:
        base = 10
        base_tier = "LOW"
    elif today_risk < 65:
        base = 25
        base_tier = "MEDIUM"
    else:
        base = 40
        base_tier = "HIGH"

    # Metro modifier
    metro = worker.city in METRO_CITIES
    metro_mult = 1.15 if metro else 1.0

    # Safety modifier (7-day avg)
    if avg_risk_7d < 35:
        safety_mult = 0.85
        safety_label = "Safe 7-day avg → -15%"
    elif avg_risk_7d > 65:
        safety_mult = 1.10
        safety_label = "High recent risk → +10%"
    else:
        safety_mult = 1.0
        safety_label = "Moderate recent risk → ±0%"

    # Night shift modifier
    night = is_night_shift(worker.shift_start, worker.shift_end)
    shift_mult = 1.05 if night else 1.0

    final = round(base * metro_mult * safety_mult * shift_mult, 2)

    return {
        "base": base,
        "base_tier": base_tier,
        "metro_multiplier": metro_mult,
        "safety_multiplier": safety_mult,
        "safety_label": safety_label,
        "shift_multiplier": shift_mult,
        "night_shift": night,
        "weekly_premium": final,
        "avg_risk_7d": avg_risk_7d,
        "avg_risk_21d": avg_risk_21d,
        "tier": base_tier,
    }

def get_active_triggers(zone_data: ZoneRisk) -> list:
    triggers = []
    if zone_data.rain > 5:
        triggers.append({"type": "rain", "label": f"Rain {zone_data.rain}mm", "icon": "🌧"})
    if zone_data.aqi > 150:
        triggers.append({"type": "aqi", "label": f"AQI {zone_data.aqi:.0f}", "icon": "💨"})
    if zone_data.traffic_level >= 4:
        triggers.append({"type": "traffic", "label": f"Traffic {zone_data.traffic_level}/5", "icon": "🚦"})
    if zone_data.curfew_status:
        triggers.append({"type": "curfew", "label": "Curfew Active", "icon": "🚫"})
    if zone_data.temperature > 38:
        triggers.append({"type": "heat", "label": f"Heat {zone_data.temperature}°C", "icon": "🌡"})
    return triggers

def get_work_advisor(score: float, zone_data) -> dict:
    if score >= 65:
        if hasattr(zone_data, 'curfew_status') and zone_data.curfew_status:
            return {"window": "Avoid all work today", "reason": "Curfew is active in your zone.",
                    "badge": "STOP", "color": "red"}
        return {"window": "9 AM – 1 PM", "reason": f"High risk expected from afternoon. Rain {getattr(zone_data, 'rain', 0):.0f}mm + heavy traffic. Safer window: morning.",
                "badge": "CAUTION", "color": "orange"}
    elif score >= 35:
        return {"window": "9 AM – 6 PM (take breaks)", "reason": "Moderate conditions. Stay alert for sudden rain or traffic spikes.",
                "badge": "ADVISORY", "color": "yellow"}
    return {"window": "All day operational", "reason": "Conditions look clear. Good day to earn.",
            "badge": "CLEAR", "color": "green"}

def compute_overlap_hours(shift_start: str, shift_end: str,
                           event_start: datetime, event_end: datetime,
                           date_ref: date) -> float:
    """Compute overlap in hours between worker shift and disruption window."""
    try:
        def to_dt(t_str: str) -> datetime:
            h, m = map(int, t_str.split(":"))
            return datetime(date_ref.year, date_ref.month, date_ref.day, h, m)

        sh = to_dt(shift_start)
        se = to_dt(shift_end)
        if se <= sh:  # crosses midnight
            se = se + timedelta(days=1)

        overlap_start = max(sh, event_start)
        overlap_end = min(se, event_end)
        if overlap_end <= overlap_start:
            return 0.0
        return round((overlap_end - overlap_start).total_seconds() / 3600, 2)
    except Exception:
        return 0.0

def calculate_shift_payout(worker: Worker, disruption_factor: float,
                            overlap_hours: float) -> float:
    """payout = daily_income × disruption_factor × (overlap / total_shift_hours)"""
    if worker.working_hours <= 0 or overlap_hours <= 0:
        return 0.0
    return round(worker.daily_income * disruption_factor * (overlap_hours / worker.working_hours), 2)

def check_fraud(worker: Worker, claimed_zone: str, db: Session):
    if worker.zone.lower() != claimed_zone.lower():
        return True, f"Worker registered zone ({worker.zone}) does not match claimed zone ({claimed_zone})"
    from models import Claim
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    existing = db.query(Claim).filter(Claim.worker_id == worker.id, Claim.created_at >= today_start).first()
    if existing:
        return True, "Duplicate claim: worker already filed a claim today"
    return False, ""

def get_premium_tier(avg_risk: float) -> dict:
    if avg_risk < 35:
        return {"tier": "LOW", "weekly_premium": 10, "color": "green"}
    elif avg_risk < 65:
        return {"tier": "MEDIUM", "weekly_premium": 25, "color": "yellow"}
    return {"tier": "HIGH", "weekly_premium": 40, "color": "red"}
