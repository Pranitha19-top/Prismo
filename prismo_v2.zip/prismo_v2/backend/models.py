from sqlalchemy import Column, Integer, String, Float, Boolean, Date, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Worker(Base):
    __tablename__ = "workers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="worker")
    city = Column(String, default="Bengaluru")
    zone = Column(String, nullable=False)
    is_metro = Column(Boolean, default=True)
    daily_income = Column(Float, nullable=False)
    working_hours = Column(Float, default=8.0)
    shift_start = Column(String, default="09:00")
    shift_end = Column(String, default="17:00")
    language = Column(String, default="en")
    payment_status = Column(String, default="ACTIVE")
    payment_due_date = Column(Date, nullable=True)
    grace_deadline = Column(Date, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ZoneRisk(Base):
    __tablename__ = "zone_risks"
    id = Column(Integer, primary_key=True, index=True)
    zone = Column(String, nullable=False, index=True)
    city = Column(String, default="Bengaluru")
    date = Column(Date, nullable=False)
    rain = Column(Float, default=0.0)
    temperature = Column(Float, default=28.0)
    aqi = Column(Float, default=80.0)
    traffic_level = Column(Float, default=3.0)
    curfew_status = Column(Boolean, default=False)
    risk_score = Column(Float, default=0.0)

class DisruptionEvent(Base):
    __tablename__ = "disruption_events"
    id = Column(Integer, primary_key=True, index=True)
    city = Column(String, nullable=False)
    zone = Column(String, nullable=False)
    event_type = Column(String, nullable=False)
    event_start = Column(DateTime, nullable=False)
    event_end = Column(DateTime, nullable=False)
    severity = Column(String, default="medium")
    disruption_factor = Column(Float, default=0.7)
    source = Column(String, default="manual")
    description = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Claim(Base):
    __tablename__ = "claims"
    id = Column(Integer, primary_key=True, index=True)
    worker_id = Column(Integer, nullable=False)
    worker_name = Column(String)
    zone = Column(String)
    event_id = Column(Integer, nullable=True)
    event_type = Column(String)
    shift_start = Column(String)
    shift_end = Column(String)
    disruption_start = Column(String)
    disruption_end = Column(String)
    overlap_hours = Column(Float, default=0.0)
    total_working_hours = Column(Float, default=8.0)
    daily_income = Column(Float, default=0.0)
    disruption_factor = Column(Float)
    payout = Column(Float)
    risk_score_at_trigger = Column(Float)
    status = Column(String, default="approved")
    fraud_flag = Column(Boolean, default=False)
    fraud_reason = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True, index=True)
    worker_id = Column(Integer, nullable=False)
    amount = Column(Float, nullable=False)
    week_start = Column(Date, nullable=False)
    week_end = Column(Date, nullable=False)
    status = Column(String, default="paid")
    paid_at = Column(DateTime, default=datetime.utcnow)

class TriggerEvent(Base):
    __tablename__ = "trigger_events"
    id = Column(Integer, primary_key=True, index=True)
    zone = Column(String)
    event_type = Column(String)
    description = Column(Text)
    severity = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
