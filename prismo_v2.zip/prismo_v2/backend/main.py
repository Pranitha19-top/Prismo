import os
import requests as req_lib
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime, timedelta

from database import get_db, init_db, seed_db
from models import Worker, ZoneRisk, Claim, DisruptionEvent, TriggerEvent, Payment
from risk_engine import (
    compute_risk_score, risk_level, get_zone_7day_avg, get_zone_21day_avg,
    get_premium_tier, get_active_triggers, get_work_advisor,
    compute_weekly_premium, compute_overlap_hours, calculate_shift_payout,
    check_fraud, METRO_CITIES
)
from auth import hash_password, verify_password, create_token, decode_token

app = FastAPI(title="PRISMO API v2", version="2.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

WEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "")

@app.on_event("startup")
def startup():
    init_db()
    seed_db()

# ── Auth helpers ─────────────────────────────────────────────────────────────

def get_current_worker(authorization: str = Header(None), db: Session = Depends(get_db)) -> Worker:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = authorization.split(" ", 1)[1]
    payload = decode_token(token)
    if not payload or "worker_id" not in payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    worker = db.query(Worker).filter(Worker.id == payload["worker_id"]).first()
    if not worker:
        raise HTTPException(status_code=401, detail="Worker not found")
    return worker

def require_admin(worker: Worker = Depends(get_current_worker)):
    if worker.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return worker

# ── Schemas ───────────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    email: str
    password: str

class SignupRequest(BaseModel):
    name: str
    email: str
    password: str
    city: str = "Bengaluru"
    zone: str = "Kasavanahalli"
    daily_income: float = 500.0
    working_hours: float = 8.0
    shift_start: str = "09:00"
    shift_end: str = "17:00"
    language: str = "en"

class ClaimRequest(BaseModel):
    event_id: int

class DisruptionEventCreate(BaseModel):
    city: str
    zone: str
    event_type: str
    event_start: str   # ISO datetime
    event_end: str
    severity: str = "medium"
    disruption_factor: float = 0.7
    description: str = ""

class AdminWorkerAction(BaseModel):
    action: str  # freeze | unfreeze | mark_paid
    worker_id: int

# ── Auth Endpoints ────────────────────────────────────────────────────────────

@app.post("/auth/login")
def login(data: LoginRequest, db: Session = Depends(get_db)):
    worker = db.query(Worker).filter(Worker.email == data.email).first()
    if not worker or not verify_password(data.password, worker.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_token({"worker_id": worker.id, "role": worker.role, "name": worker.name})
    return {
        "token": token,
        "worker": {
            "id": worker.id, "name": worker.name, "email": worker.email,
            "role": worker.role, "zone": worker.zone, "city": worker.city,
            "language": worker.language, "payment_status": worker.payment_status,
        }
    }

@app.post("/auth/signup")
def signup(data: SignupRequest, db: Session = Depends(get_db)):
    if db.query(Worker).filter(Worker.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    is_metro = data.city in METRO_CITIES
    today = date.today()
    worker = Worker(
        name=data.name, email=data.email,
        password_hash=hash_password(data.password),
        role="worker", city=data.city, zone=data.zone,
        is_metro=is_metro, daily_income=data.daily_income,
        working_hours=data.working_hours,
        shift_start=data.shift_start, shift_end=data.shift_end,
        language=data.language, payment_status="ACTIVE",
        payment_due_date=today + timedelta(days=7),
        grace_deadline=today + timedelta(days=9),
    )
    db.add(worker)
    db.commit()
    db.refresh(worker)
    token = create_token({"worker_id": worker.id, "role": worker.role, "name": worker.name})
    return {"token": token, "worker": {"id": worker.id, "name": worker.name, "role": worker.role}}

@app.get("/auth/me")
def get_me(current: Worker = Depends(get_current_worker)):
    return {
        "id": current.id, "name": current.name, "email": current.email,
        "role": current.role, "zone": current.zone, "city": current.city,
        "is_metro": current.is_metro, "daily_income": current.daily_income,
        "working_hours": current.working_hours,
        "shift_start": current.shift_start, "shift_end": current.shift_end,
        "language": current.language, "payment_status": current.payment_status,
        "payment_due_date": str(current.payment_due_date) if current.payment_due_date else None,
        "grace_deadline": str(current.grace_deadline) if current.grace_deadline else None,
    }

# ── Worker Dashboard ──────────────────────────────────────────────────────────

@app.get("/workers/{worker_id}/dashboard")
def get_worker_dashboard(worker_id: int, db: Session = Depends(get_db)):
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")

    today = date.today()
    zd = db.query(ZoneRisk).filter(ZoneRisk.zone == worker.zone, ZoneRisk.date == today).first()
    if not zd:
        zd = db.query(ZoneRisk).filter(ZoneRisk.zone == worker.zone).order_by(ZoneRisk.date.desc()).first()

    if zd:
        score = zd.risk_score
        triggers = get_active_triggers(zd)
        advisor = get_work_advisor(score, zd)
    else:
        score = 30.0
        triggers = []
        advisor = get_work_advisor(30.0, type('obj', (object,), {'curfew_status': False, 'rain': 0})())

    premium = compute_weekly_premium(worker, db)
    claims = db.query(Claim).filter(Claim.worker_id == worker_id).order_by(Claim.created_at.desc()).limit(5).all()

    # Active disruptions for worker's zone
    now = datetime.utcnow()
    active_events = db.query(DisruptionEvent).filter(
        DisruptionEvent.zone == worker.zone,
        DisruptionEvent.event_start <= now,
        DisruptionEvent.event_end >= now,
    ).all()

    return {
        "worker": {
            "id": worker.id, "name": worker.name, "zone": worker.zone,
            "city": worker.city, "is_metro": worker.is_metro,
            "daily_income": worker.daily_income, "working_hours": worker.working_hours,
            "shift_start": worker.shift_start, "shift_end": worker.shift_end,
            "payment_status": worker.payment_status,
            "payment_due_date": str(worker.payment_due_date) if worker.payment_due_date else None,
            "grace_deadline": str(worker.grace_deadline) if worker.grace_deadline else None,
        },
        "current_risk": {"score": score, "level": risk_level(score)},
        "active_triggers": triggers,
        "advisor": advisor,
        "premium": premium,
        "zone_conditions": {
            "rain": round(zd.rain, 1) if zd else 0,
            "temperature": zd.temperature if zd else 28,
            "aqi": round(zd.aqi, 1) if zd else 80,
            "traffic_level": zd.traffic_level if zd else 3,
            "curfew": zd.curfew_status if zd else False,
        },
        "active_disruption_events": [
            {
                "id": e.id, "event_type": e.event_type,
                "event_start": e.event_start.strftime("%H:%M"),
                "event_end": e.event_end.strftime("%H:%M"),
                "disruption_factor": e.disruption_factor,
                "severity": e.severity, "description": e.description,
                "overlap_hours": compute_overlap_hours(
                    worker.shift_start, worker.shift_end,
                    e.event_start, e.event_end, today
                ),
            }
            for e in active_events
        ],
        "recent_claims": [
            {
                "id": c.id, "event": c.event_type, "payout": c.payout,
                "overlap_hours": c.overlap_hours, "status": c.status,
                "date": c.created_at.strftime("%d %b %Y %H:%M")
            }
            for c in claims
        ],
    }

@app.get("/workers")
def get_workers(db: Session = Depends(get_db)):
    workers = db.query(Worker).filter(Worker.role == "worker").all()
    return [{"id": w.id, "name": w.name, "zone": w.zone, "city": w.city,
             "daily_income": w.daily_income, "payment_status": w.payment_status} for w in workers]

# ── Zones ─────────────────────────────────────────────────────────────────────

@app.get("/zones")
def get_all_zones(db: Session = Depends(get_db)):
    zones = list({
        "Kasavanahalli", "Bellandur", "HSR Layout", "Electronic City",
        "Whitefield", "Marathahalli", "Lakdikapul", "Banjara Hills", "Hitech City"
    })
    today = date.today()
    result = []
    for zone in zones:
        zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone, ZoneRisk.date == today).first()
        if not zd:
            zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone).order_by(ZoneRisk.date.desc()).first()
        if zd:
            score = zd.risk_score
            lv = risk_level(score)
            result.append({
                "zone": zone, "city": zd.city, "risk_score": score, "risk_level": lv,
                "rain": round(zd.rain, 1), "aqi": round(zd.aqi, 1),
                "traffic_level": zd.traffic_level, "curfew": zd.curfew_status,
                "temperature": zd.temperature
            })
    return result

@app.get("/zones/{zone}/risk")
def get_zone_risk(zone: str, db: Session = Depends(get_db)):
    today = date.today()
    zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone, ZoneRisk.date == today).first()
    if not zd:
        zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone).order_by(ZoneRisk.date.desc()).first()
    if not zd:
        raise HTTPException(status_code=404, detail="Zone not found")
    return {
        "zone": zone, "city": zd.city, "risk_score": zd.risk_score,
        "risk_level": risk_level(zd.risk_score),
        "rain": round(zd.rain, 1), "temperature": zd.temperature,
        "aqi": round(zd.aqi, 1), "traffic_level": zd.traffic_level,
        "curfew": zd.curfew_status, "date": str(zd.date)
    }

@app.get("/zones/{zone}/premium")
def get_zone_premium(zone: str, db: Session = Depends(get_db)):
    avg = get_zone_21day_avg(db, zone)
    premium = get_premium_tier(avg)
    history = db.query(ZoneRisk).filter(ZoneRisk.zone == zone).order_by(ZoneRisk.date.desc()).limit(21).all()
    return {
        "zone": zone, "avg_risk_21d": avg, "premium": premium,
        "history": [{"date": str(r.date), "risk_score": r.risk_score, "risk_level": risk_level(r.risk_score)} for r in history]
    }

# ── Claims ────────────────────────────────────────────────────────────────────

@app.post("/claims/trigger")
def trigger_claim(data: ClaimRequest, db: Session = Depends(get_db),
                  current: Worker = Depends(get_current_worker)):
    if current.payment_status == "FROZEN":
        raise HTTPException(status_code=403, detail="Account frozen. Pay premium to reactivate.")

    event = db.query(DisruptionEvent).filter(DisruptionEvent.id == data.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Disruption event not found")

    # Zone match check
    if event.zone.lower() != current.zone.lower():
        raise HTTPException(status_code=400,
            detail=f"This event is for zone '{event.zone}', not your zone '{current.zone}'")

    today = date.today()
    overlap = compute_overlap_hours(
        current.shift_start, current.shift_end,
        event.event_start, event.event_end, today
    )

    payout = calculate_shift_payout(current, event.disruption_factor, overlap)
    status = "approved" if overlap > 0 else "not_eligible"

    zd = db.query(ZoneRisk).filter(ZoneRisk.zone == current.zone, ZoneRisk.date == today).first()
    score = zd.risk_score if zd else 50.0

    claim = Claim(
        worker_id=current.id, worker_name=current.name,
        zone=current.zone, event_id=event.id,
        event_type=event.event_type,
        shift_start=current.shift_start, shift_end=current.shift_end,
        disruption_start=event.event_start.strftime("%H:%M"),
        disruption_end=event.event_end.strftime("%H:%M"),
        overlap_hours=overlap, total_working_hours=current.working_hours,
        daily_income=current.daily_income,
        disruption_factor=event.disruption_factor,
        payout=payout, risk_score_at_trigger=score,
        status=status, fraud_flag=False,
    )
    db.add(claim)

    te = TriggerEvent(
        zone=current.zone, event_type="claim",
        description=f"{'Claim approved' if overlap > 0 else 'Not eligible'}: {current.name} — ₹{payout:.0f} ({overlap}h overlap)",
        severity="low" if overlap > 0 else "info",
    )
    db.add(te)
    db.commit()

    return {
        "claim_id": claim.id, "worker": current.name, "zone": current.zone,
        "event_type": event.event_type,
        "shift": f"{current.shift_start}–{current.shift_end}",
        "disruption_window": f"{event.event_start.strftime('%H:%M')}–{event.event_end.strftime('%H:%M')}",
        "overlap_hours": overlap,
        "total_working_hours": current.working_hours,
        "daily_income": current.daily_income,
        "disruption_factor": event.disruption_factor,
        "formula": f"₹{current.daily_income} × {event.disruption_factor} × ({overlap}/{current.working_hours}h)",
        "payout": payout, "status": status,
    }

@app.get("/claims")
def get_claims(worker_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(Claim)
    if worker_id:
        q = q.filter(Claim.worker_id == worker_id)
    claims = q.order_by(Claim.created_at.desc()).all()
    return [
        {
            "id": c.id, "worker": c.worker_name, "zone": c.zone,
            "event": c.event_type,
            "shift": f"{c.shift_start}–{c.shift_end}",
            "disruption_window": f"{c.disruption_start}–{c.disruption_end}",
            "overlap_hours": c.overlap_hours,
            "total_working_hours": c.total_working_hours,
            "daily_income": c.daily_income,
            "disruption_factor": c.disruption_factor,
            "payout": c.payout, "status": c.status,
            "fraud": c.fraud_flag, "fraud_reason": c.fraud_reason,
            "timestamp": c.created_at.strftime("%d %b %Y %H:%M"),
        }
        for c in claims
    ]

# ── Disruption Events ─────────────────────────────────────────────────────────

@app.get("/disruption-events")
def get_disruption_events(zone: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(DisruptionEvent)
    if zone:
        q = q.filter(DisruptionEvent.zone == zone)
    events = q.order_by(DisruptionEvent.created_at.desc()).all()
    return [
        {
            "id": e.id, "city": e.city, "zone": e.zone,
            "event_type": e.event_type, "severity": e.severity,
            "disruption_factor": e.disruption_factor,
            "event_start": e.event_start.strftime("%Y-%m-%d %H:%M"),
            "event_end": e.event_end.strftime("%Y-%m-%d %H:%M"),
            "source": e.source, "description": e.description,
            "created_at": e.created_at.strftime("%d %b %Y %H:%M"),
        }
        for e in events
    ]

@app.post("/admin/disruption-events")
def create_disruption_event(data: DisruptionEventCreate,
                             admin: Worker = Depends(require_admin),
                             db: Session = Depends(get_db)):
    event = DisruptionEvent(
        city=data.city, zone=data.zone, event_type=data.event_type,
        event_start=datetime.fromisoformat(data.event_start),
        event_end=datetime.fromisoformat(data.event_end),
        severity=data.severity, disruption_factor=data.disruption_factor,
        description=data.description, source="manual",
    )
    db.add(event)
    db.flush()

    # Log feed
    te = TriggerEvent(
        zone=data.zone, event_type=data.event_type,
        description=f"[Admin] {data.description or data.event_type} in {data.zone}",
        severity=data.severity,
    )
    db.add(te)
    db.commit()

    return {"id": event.id, "message": "Disruption event created"}

# ── Payment ───────────────────────────────────────────────────────────────────

@app.post("/payments/pay")
def make_payment(db: Session = Depends(get_db),
                 current: Worker = Depends(get_current_worker)):
    if current.payment_status not in ("PAYMENT_DUE", "GRACE_PERIOD", "FROZEN", "ACTIVE"):
        raise HTTPException(status_code=400, detail="Payment not applicable")

    premium_info = compute_weekly_premium(current, db)
    amount = premium_info["weekly_premium"]
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    week_end = week_start + timedelta(days=6)

    payment = Payment(
        worker_id=current.id, amount=amount,
        week_start=week_start, week_end=week_end,
        status="paid", paid_at=datetime.utcnow(),
    )
    db.add(payment)

    # Update worker
    current.payment_status = "ACTIVE"
    current.payment_due_date = today + timedelta(days=7)
    current.grace_deadline = today + timedelta(days=9)
    db.commit()

    return {"success": True, "amount_paid": amount, "next_due": str(current.payment_due_date)}

@app.get("/payments/history")
def payment_history(db: Session = Depends(get_db),
                    current: Worker = Depends(get_current_worker)):
    payments = db.query(Payment).filter(Payment.worker_id == current.id)\
        .order_by(Payment.paid_at.desc()).all()
    return [
        {
            "id": p.id, "amount": p.amount,
            "week_start": str(p.week_start), "week_end": str(p.week_end),
            "status": p.status, "paid_at": p.paid_at.strftime("%d %b %Y"),
        }
        for p in payments
    ]

# ── Admin ─────────────────────────────────────────────────────────────────────

@app.get("/admin/dashboard")
def get_admin_dashboard(db: Session = Depends(get_db)):
    zones = ["Kasavanahalli", "Bellandur", "HSR Layout", "Electronic City",
             "Whitefield", "Marathahalli", "Lakdikapul", "Banjara Hills", "Hitech City"]
    today = date.today()
    zones_data = []
    high_risk_count = 0

    for zone in zones:
        zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone, ZoneRisk.date == today).first()
        if not zd:
            zd = db.query(ZoneRisk).filter(ZoneRisk.zone == zone).order_by(ZoneRisk.date.desc()).first()
        avg = get_zone_21day_avg(db, zone)
        premium = get_premium_tier(avg)
        if zd:
            score = zd.risk_score
            lv = risk_level(score)
            if lv == "HIGH":
                high_risk_count += 1
            zones_data.append({
                "zone": zone, "city": zd.city, "current_score": score, "current_level": lv,
                "avg_risk_21d": avg, "premium_tier": premium["tier"],
                "weekly_premium": premium["weekly_premium"],
                "rain": round(zd.rain, 1), "aqi": round(zd.aqi, 1),
                "traffic": zd.traffic_level, "curfew": zd.curfew_status,
            })

    workers = db.query(Worker).filter(Worker.role == "worker").all()
    worker_list = []
    for w in workers:
        pm = compute_weekly_premium(w, db)
        worker_list.append({
            "id": w.id, "name": w.name, "city": w.city, "zone": w.zone,
            "is_metro": w.is_metro, "daily_income": w.daily_income,
            "shift_start": w.shift_start, "shift_end": w.shift_end,
            "payment_status": w.payment_status,
            "payment_due_date": str(w.payment_due_date) if w.payment_due_date else None,
            "grace_deadline": str(w.grace_deadline) if w.grace_deadline else None,
            "weekly_premium": pm["weekly_premium"],
        })

    total_workers = len(workers)
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    claims_today = db.query(Claim).filter(Claim.created_at >= today_start).count()
    all_claims = db.query(Claim).all()
    total_payout = sum(c.payout for c in all_claims)
    frozen_count = db.query(Worker).filter(Worker.payment_status == "FROZEN").count()
    grace_count = db.query(Worker).filter(Worker.payment_status == "GRACE_PERIOD").count()

    return {
        "kpis": {
            "active_workers": total_workers,
            "high_risk_zones": high_risk_count,
            "claims_today": claims_today,
            "frozen_accounts": frozen_count,
            "grace_accounts": grace_count,
            "total_payout": round(total_payout, 2),
        },
        "zones": zones_data,
        "workers": worker_list,
    }

@app.post("/admin/worker-action")
def admin_worker_action(data: AdminWorkerAction,
                        admin: Worker = Depends(require_admin),
                        db: Session = Depends(get_db)):
    worker = db.query(Worker).filter(Worker.id == data.worker_id).first()
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")

    today = date.today()
    if data.action == "freeze":
        worker.payment_status = "FROZEN"
    elif data.action == "unfreeze":
        worker.payment_status = "ACTIVE"
        worker.payment_due_date = today + timedelta(days=7)
        worker.grace_deadline = today + timedelta(days=9)
    elif data.action == "mark_paid":
        worker.payment_status = "ACTIVE"
        worker.payment_due_date = today + timedelta(days=7)
        worker.grace_deadline = today + timedelta(days=9)
        pm = compute_weekly_premium(worker, db)
        week_start = today - timedelta(days=today.weekday())
        db.add(Payment(
            worker_id=worker.id, amount=pm["weekly_premium"],
            week_start=week_start, week_end=week_start + timedelta(days=6),
            status="paid", paid_at=datetime.utcnow(),
        ))
    else:
        raise HTTPException(status_code=400, detail="Unknown action")

    db.commit()
    return {"success": True, "worker": worker.name, "status": worker.payment_status}

@app.get("/admin/fraud-alerts")
def get_fraud_alerts(db: Session = Depends(get_db)):
    frauds = db.query(Claim).filter(Claim.fraud_flag == True).order_by(Claim.created_at.desc()).all()
    return [
        {"id": c.id, "worker": c.worker_name, "zone": c.zone,
         "reason": c.fraud_reason, "payout_blocked": c.payout,
         "timestamp": c.created_at.strftime("%d %b %Y %H:%M")}
        for c in frauds
    ]

@app.get("/admin/trigger-feed")
def get_trigger_feed(db: Session = Depends(get_db)):
    events = db.query(TriggerEvent).order_by(TriggerEvent.created_at.desc()).limit(30).all()
    return [
        {"id": e.id, "zone": e.zone, "type": e.event_type,
         "description": e.description, "severity": e.severity,
         "timestamp": e.created_at.strftime("%d %b %Y %H:%M")}
        for e in events
    ]

@app.get("/admin/zone-analytics")
def get_zone_analytics(db: Session = Depends(get_db)):
    zones = ["Kasavanahalli", "Bellandur", "HSR Layout", "Electronic City",
             "Whitefield", "Marathahalli", "Lakdikapul"]
    result = []
    for zone in zones:
        avg = get_zone_21day_avg(db, zone)
        claims = db.query(Claim).filter(Claim.zone == zone).all()
        payout_sum = sum(c.payout for c in claims)
        result.append({
            "zone": zone, "avg_risk": avg, "risk_level": risk_level(avg),
            "claims_count": len(claims), "total_payout": round(payout_sum, 2),
            "premium": get_premium_tier(avg),
        })
    result.sort(key=lambda x: x["avg_risk"], reverse=True)
    return result

@app.get("/admin/same-zone-comparison")
def same_zone_comparison(zone: str, db: Session = Depends(get_db)):
    workers = db.query(Worker).filter(Worker.zone == zone, Worker.role == "worker").all()
    result = []
    for w in workers:
        claims = db.query(Claim).filter(Claim.worker_id == w.id).order_by(Claim.created_at.desc()).all()
        pm = compute_weekly_premium(w, db)
        result.append({
            "id": w.id, "name": w.name, "shift": f"{w.shift_start}–{w.shift_end}",
            "daily_income": w.daily_income, "payment_status": w.payment_status,
            "weekly_premium": pm["weekly_premium"],
            "total_payout": sum(c.payout for c in claims),
            "claims_count": len(claims),
            "latest_claim": {
                "overlap_hours": claims[0].overlap_hours,
                "payout": claims[0].payout,
                "event": claims[0].event_type,
            } if claims else None,
        })
    return {"zone": zone, "workers": result}

# ── Live Weather ──────────────────────────────────────────────────────────────

@app.get("/weather/{city}")
def get_weather(city: str):
    if not WEATHER_API_KEY:
        return {"source": "demo", "city": city, "rain": 8.2, "temperature": 29,
                "aqi": 115, "description": "Demo data — add OPENWEATHER_API_KEY for live"}
    try:
        r = req_lib.get(
            "https://api.openweathermap.org/data/2.5/weather",
            params={"q": city, "appid": WEATHER_API_KEY, "units": "metric"},
            timeout=5
        )
        d = r.json()
        return {
            "source": "live",
            "city": d.get("name", city),
            "temperature": d["main"]["temp"],
            "rain": d.get("rain", {}).get("1h", 0),
            "description": d["weather"][0]["description"] if d.get("weather") else "",
        }
    except Exception:
        return {"source": "demo", "city": city, "rain": 8.2, "temperature": 29,
                "aqi": 115, "description": "Live API unavailable — showing demo data"}
