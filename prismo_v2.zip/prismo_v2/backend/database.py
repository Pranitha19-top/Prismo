from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Worker, ZoneRisk, Claim, DisruptionEvent, TriggerEvent, Payment
from datetime import date, datetime, timedelta
from auth import hash_password
import random

DATABASE_URL = "sqlite:///./prismo.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    Base.metadata.create_all(bind=engine)

ZONES_BLR = ["Kasavanahalli", "Bellandur", "HSR Layout", "Electronic City", "Whitefield", "Marathahalli"]
ZONES_HYD = ["Lakdikapul", "Banjara Hills", "Hitech City"]

def compute_risk_score(rain, temperature, aqi, traffic_level, curfew_status):
    if curfew_status:
        return 100.0
    score = 0.0
    score += min(rain / 20.0, 1.0) * 30
    score += min(aqi / 300.0, 1.0) * 20
    temp_factor = max(0, (temperature - 35) / 10.0) + max(0, (15 - temperature) / 10.0)
    score += min(temp_factor, 1.0) * 10
    score += ((traffic_level - 1) / 4.0) * 25
    score += 15
    return round(min(score, 100.0), 2)

def seed_db():
    db = SessionLocal()
    try:
        if db.query(Worker).count() > 0:
            print("DB already seeded.")
            return

        today = date.today()

        # ── Workers ──────────────────────────────────────────────────────────
        workers_data = [
            # Demo workers requested
            {
                "name": "Ravi Kumar", "email": "ravi@prismo.in",
                "password_hash": hash_password("ravi123"),
                "role": "worker", "city": "Bengaluru", "zone": "Kasavanahalli",
                "is_metro": True, "daily_income": 700, "working_hours": 7,
                "shift_start": "09:00", "shift_end": "16:00", "language": "en",
                "payment_status": "ACTIVE",
                "payment_due_date": today + timedelta(days=3),
                "grace_deadline": today + timedelta(days=5),
            },
            {
                "name": "Himesh Sharma", "email": "himesh@prismo.in",
                "password_hash": hash_password("himesh123"),
                "role": "worker", "city": "Bengaluru", "zone": "Kasavanahalli",
                "is_metro": True, "daily_income": 680, "working_hours": 6,
                "shift_start": "15:00", "shift_end": "21:00", "language": "hi",
                "payment_status": "PAYMENT_DUE",
                "payment_due_date": today - timedelta(days=1),
                "grace_deadline": today + timedelta(days=1),
            },
            {
                "name": "Priya Devi", "email": "priya@prismo.in",
                "password_hash": hash_password("priya123"),
                "role": "worker", "city": "Bengaluru", "zone": "HSR Layout",
                "is_metro": True, "daily_income": 750, "working_hours": 8,
                "shift_start": "08:00", "shift_end": "16:00", "language": "en",
                "payment_status": "ACTIVE",
                "payment_due_date": today + timedelta(days=7),
                "grace_deadline": today + timedelta(days=9),
            },
            {
                "name": "Suresh Nair", "email": "suresh@prismo.in",
                "password_hash": hash_password("suresh123"),
                "role": "worker", "city": "Hyderabad", "zone": "Lakdikapul",
                "is_metro": True, "daily_income": 620, "working_hours": 9,
                "shift_start": "10:00", "shift_end": "19:00", "language": "en",
                "payment_status": "FROZEN",
                "payment_due_date": today - timedelta(days=10),
                "grace_deadline": today - timedelta(days=8),
            },
            # Additional workers for zone variety
            {
                "name": "Arjun Reddy", "email": "arjun@prismo.in",
                "password_hash": hash_password("arjun123"),
                "role": "worker", "city": "Bengaluru", "zone": "Bellandur",
                "is_metro": True, "daily_income": 650, "working_hours": 9,
                "shift_start": "08:00", "shift_end": "17:00", "language": "en",
                "payment_status": "ACTIVE",
                "payment_due_date": today + timedelta(days=5),
                "grace_deadline": today + timedelta(days=7),
            },
            {
                "name": "Meena S", "email": "meena@prismo.in",
                "password_hash": hash_password("meena123"),
                "role": "worker", "city": "Bengaluru", "zone": "Whitefield",
                "is_metro": True, "daily_income": 720, "working_hours": 8,
                "shift_start": "21:00", "shift_end": "05:00", "language": "en",
                "payment_status": "GRACE_PERIOD",
                "payment_due_date": today - timedelta(days=2),
                "grace_deadline": today,
            },
        ]

        workers = []
        for w in workers_data:
            worker = Worker(**w)
            db.add(worker)
            workers.append(worker)
        db.flush()

        # Admin
        admin = Worker(
            name="Admin PRISMO", email="admin@prismo.in",
            password_hash=hash_password("admin123"),
            role="admin", city="Bengaluru", zone="Kasavanahalli",
            is_metro=True, daily_income=0, working_hours=8,
            shift_start="09:00", shift_end="17:00", language="en",
            payment_status="ACTIVE",
            payment_due_date=today + timedelta(days=30),
            grace_deadline=today + timedelta(days=32),
        )
        db.add(admin)
        db.flush()

        # ── Zone Risk — 21 days ───────────────────────────────────────────────
        zone_profiles = {
            "Kasavanahalli": {"city": "Bengaluru", "base_rain": 8, "base_aqi": 120, "base_traffic": 3.5},
            "Bellandur":     {"city": "Bengaluru", "base_rain": 12, "base_aqi": 160, "base_traffic": 4.2},
            "HSR Layout":    {"city": "Bengaluru", "base_rain": 5, "base_aqi": 90, "base_traffic": 3.0},
            "Electronic City":{"city": "Bengaluru","base_rain": 4, "base_aqi": 100, "base_traffic": 2.8},
            "Whitefield":    {"city": "Bengaluru", "base_rain": 10, "base_aqi": 140, "base_traffic": 4.0},
            "Marathahalli":  {"city": "Bengaluru", "base_rain": 15, "base_aqi": 180, "base_traffic": 4.5},
            "Lakdikapul":    {"city": "Hyderabad", "base_rain": 6, "base_aqi": 110, "base_traffic": 3.2},
            "Banjara Hills": {"city": "Hyderabad", "base_rain": 4, "base_aqi": 95, "base_traffic": 2.9},
            "Hitech City":   {"city": "Hyderabad", "base_rain": 7, "base_aqi": 130, "base_traffic": 3.8},
        }

        for i in range(21):
            day = today - timedelta(days=20 - i)
            for zone, p in zone_profiles.items():
                rain = max(0, p["base_rain"] + random.gauss(0, 4))
                aqi = max(30, p["base_aqi"] + random.gauss(0, 25))
                temperature = round(28 + random.gauss(0, 3), 1)
                traffic = round(min(5, max(1, p["base_traffic"] + random.gauss(0, 0.5))), 1)
                curfew = (zone == "Marathahalli" and i in [3, 7]) or (zone == "Bellandur" and i == 12)
                score = compute_risk_score(rain, temperature, aqi, traffic, curfew)
                db.add(ZoneRisk(
                    zone=zone, city=p["city"], date=day,
                    rain=round(rain, 1), temperature=temperature,
                    aqi=round(aqi, 1), traffic_level=traffic,
                    curfew_status=curfew, risk_score=score
                ))

        # ── Disruption Events ─────────────────────────────────────────────────
        now = datetime.utcnow()
        disruption_events = [
            # Active event in Kasavanahalli — affects Ravi AND Himesh differently
            DisruptionEvent(
                city="Bengaluru", zone="Kasavanahalli",
                event_type="rain", severity="high",
                disruption_factor=0.8,
                event_start=now.replace(hour=13, minute=0, second=0),
                event_end=now.replace(hour=18, minute=0, second=0),
                source="demo",
                description="Heavy rain — 3PM to 6PM. Ravi (9AM-4PM) loses 1h. Himesh (3PM-9PM) loses 3h.",
            ),
            # HSR Layout event
            DisruptionEvent(
                city="Bengaluru", zone="HSR Layout",
                event_type="traffic", severity="medium",
                disruption_factor=0.6,
                event_start=now.replace(hour=17, minute=0, second=0),
                event_end=now.replace(hour=20, minute=0, second=0),
                source="demo",
                description="Traffic surge on 27th Main, HSR Layout.",
            ),
            # Old resolved event
            DisruptionEvent(
                city="Bengaluru", zone="Bellandur",
                event_type="aqi", severity="high",
                disruption_factor=0.7,
                event_start=now - timedelta(days=2, hours=3),
                event_end=now - timedelta(days=2),
                source="demo",
                description="AQI spike above 200 in Bellandur.",
            ),
        ]
        for de in disruption_events:
            db.add(de)
        db.flush()

        # ── Claims (seeded with shift-overlap logic) ───────────────────────
        # Ravi: shift 9-4, disruption 3-6 PM → overlap = 1h
        ravi = workers[0]
        himesh = workers[1]
        priya = workers[2]

        claims_seed = [
            Claim(
                worker_id=ravi.id, worker_name=ravi.name,
                zone="Kasavanahalli", event_type="Heavy Rain",
                shift_start="09:00", shift_end="16:00",
                disruption_start="15:00", disruption_end="18:00",
                overlap_hours=1.0, total_working_hours=7.0,
                daily_income=700.0, disruption_factor=0.8,
                payout=round(700 * 0.8 * (1.0/7.0), 2),
                risk_score_at_trigger=72.0, status="approved",
                created_at=now - timedelta(hours=2),
            ),
            Claim(
                worker_id=himesh.id, worker_name=himesh.name,
                zone="Kasavanahalli", event_type="Heavy Rain",
                shift_start="15:00", shift_end="21:00",
                disruption_start="15:00", disruption_end="18:00",
                overlap_hours=3.0, total_working_hours=6.0,
                daily_income=680.0, disruption_factor=0.8,
                payout=round(680 * 0.8 * (3.0/6.0), 2),
                risk_score_at_trigger=72.0, status="approved",
                created_at=now - timedelta(hours=2),
            ),
            Claim(
                worker_id=priya.id, worker_name=priya.name,
                zone="HSR Layout", event_type="Traffic Jam",
                shift_start="08:00", shift_end="16:00",
                disruption_start="17:00", disruption_end="20:00",
                overlap_hours=0.0, total_working_hours=8.0,
                daily_income=750.0, disruption_factor=0.6,
                payout=0.0,
                risk_score_at_trigger=55.0, status="not_eligible",
                created_at=now - timedelta(hours=1),
            ),
        ]
        for c in claims_seed:
            db.add(c)

        # ── Payments ─────────────────────────────────────────────────────────
        week_start = today - timedelta(days=today.weekday())
        for w in workers[:3]:
            db.add(Payment(
                worker_id=w.id, amount=25.0,
                week_start=week_start - timedelta(weeks=1),
                week_end=week_start - timedelta(days=1),
                status="paid", paid_at=datetime.utcnow() - timedelta(days=7),
            ))

        # ── Trigger Feed ─────────────────────────────────────────────────────
        feed = [
            TriggerEvent(zone="Kasavanahalli", event_type="rain",
                         description="Heavy rain detected — 18mm. Ravi & Himesh affected.", severity="high",
                         created_at=now - timedelta(minutes=15)),
            TriggerEvent(zone="HSR Layout", event_type="traffic",
                         description="Traffic surge — level 4.2/5 on 27th Main.", severity="medium",
                         created_at=now - timedelta(minutes=40)),
            TriggerEvent(zone="Lakdikapul", event_type="aqi",
                         description="AQI alert 175 — Suresh account frozen.", severity="high",
                         created_at=now - timedelta(minutes=90)),
            TriggerEvent(zone="Kasavanahalli", event_type="claim",
                         description=f"Claim approved: Ravi Kumar ₹{round(700*0.8*(1/7),0):.0f} (1h overlap)", severity="low",
                         created_at=now - timedelta(minutes=10)),
            TriggerEvent(zone="Kasavanahalli", event_type="claim",
                         description=f"Claim approved: Himesh Sharma ₹{round(680*0.8*(3/6),0):.0f} (3h overlap)", severity="low",
                         created_at=now - timedelta(minutes=10)),
        ]
        for f in feed:
            db.add(f)

        db.commit()
        print("✅ Database seeded successfully.")
    except Exception as e:
        db.rollback()
        print(f"Seed error: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    init_db()
    seed_db()
